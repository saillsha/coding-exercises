package Arrays;
import java.util.*;

public class TwoSigmaCodeTestJumbleSort {
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		String line = scanner.nextLine();
		sortLine(line);
	}
	private static void sortLine(String line){
		PriorityQueue<Integer> numList = new PriorityQueue<Integer>();
		PriorityQueue<String> strList = new PriorityQueue<String>();
		List<Boolean> indices = new LinkedList<Boolean>(); //true for number, false for string
		
		StringTokenizer tok = new StringTokenizer(line, " ");
		while(tok.hasMoreElements()){
			String nextToken = tok.nextToken();
			//string if starts with a-z, number otherwise
			if(nextToken.charAt(0) >= 'a' && nextToken.charAt(0) <= 'z'){
				indices.add(false);
				strList.offer(nextToken);
			}
			else{
				indices.add(true);
				numList.offer(Integer.parseInt(nextToken));
			}
		}
		//use heap sort along with proper indexing
		for(Boolean b : indices){
			if(b)
				System.out.print(numList.poll()+" ");
			else
				System.out.print(strList.poll()+" ");
		}
	}
}
