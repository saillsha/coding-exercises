package Arrays;
import java.util.*;

public class TwoSigmaCodeTestCopyFile {
	public static void main(String[] args){
		copyFiles();	
	}
	private static void copyFiles(){
		Scanner scanner = new Scanner(System.in);
		int numDataCenters = scanner.nextInt();
		//list of data centers where each element contains a set of the data it contains
		ArrayList<HashSet<Integer>> dataCenters = new ArrayList<HashSet<Integer>>(numDataCenters);
		//maps data IDs to the data center which contains it
		HashMap<Integer, Integer> dataLocation = new HashMap<Integer, Integer>();
		
		//create set of data for each data center and map current data center to the data ID
		for(int i=1; i<=numDataCenters; i++){
			HashSet<Integer> dataCenter = new HashSet<Integer>();
			int numData = scanner.nextInt();
			for(;numData>0; numData--){
				int dataID = scanner.nextInt();
				dataCenter.add(dataID);
				dataLocation.put(dataID, i);
			}
			dataCenters.add(dataCenter);
		}
		
		Set<Integer> allData = dataLocation.keySet();
		// iterate through all data centers, finding which data are missing 
		// and copying them for a data center which contains it
		for(int i=0; i < dataCenters.size(); i++)
			for(Integer remaining : allData)
				if(!dataCenters.get(i).contains(remaining))
					System.out.println(remaining+" "+dataLocation.get(remaining)+" "+(i+1));			
	}
}
